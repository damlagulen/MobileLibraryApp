package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val CreamBackground = Color(0xFFEAE4DB)
val SoftBeige = Color(0xFFE8DCC8)

val SageGreen = Color(0xFF8FAF8F)
val OliveGreen = Color(0xFF5F7A61)

val CoffeeBrown = Color(0xFF6B4F3F)
val DarkText = Color(0xFF2F2A25)

val CardWhite = Color(0xFFFFFBF5)

val BottomBarBrown = Color(0xFFB89B7A)
val BottomBarSelected = Color(0xFFD8C3A5)