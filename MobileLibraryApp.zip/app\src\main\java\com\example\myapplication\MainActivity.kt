package com.example.myapplication

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import com.example.myapplication.ui.theme.BottomBarBrown
import com.example.myapplication.ui.theme.BottomBarSelected
import androidx.compose.material3.CardDefaults
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontStyle


const val BASE_URL = "http://192.168.1.109:8000"
const val GOOGLE_BOOKS_API_KEY = ""

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                App()
            }
        }
    }
}

@Composable
fun App() {
    var loggedInUserId by remember { mutableStateOf<Int?>(null) }
    var loggedInUsername by remember { mutableStateOf("") }
    var loggedInFullName by remember { mutableStateOf("") }
    var showRegisterScreen by remember { mutableStateOf(false) }
    var myLibraryBooks by remember { mutableStateOf(listOf<LibraryBook>()) }

    if (loggedInUserId != null) {
        HomeScreen(
            userId = loggedInUserId!!,
            username = loggedInUsername,
            fullName = loggedInFullName,
            myLibraryBooks = myLibraryBooks,
            onAddBook = { book ->
                if (myLibraryBooks.none { it.book.googleBookId == book.googleBookId }) {
                    myLibraryBooks = myLibraryBooks + LibraryBook(
                        book = book,
                        status = "Plan to Read"
                    )

                    kotlinx.coroutines.GlobalScope.launch {
                        val savedBookId = saveBookToBackend(book)

                        if (savedBookId != null) {
                            saveUserBookToBackend(
                                userId = loggedInUserId!!,
                                bookId = savedBookId,
                                currentPage = 0,
                                status = "Plan to Read"
                            )
                        }
                    }
                }
            },
            onRemoveBook = { book ->
                myLibraryBooks = myLibraryBooks.filter {
                    it.book.googleBookId != book.googleBookId
                }

                kotlinx.coroutines.GlobalScope.launch {
                    removeBookFromBackend(
                        userId = loggedInUserId!!,
                        googleBookId = book.googleBookId
                    )
                }
            },
            onUpdateProgress = { book, currentPage ->
                val newStatus = when {
                    book.pageCount > 0 && currentPage >= book.pageCount -> "Completed"
                    currentPage > 0 -> "Reading"
                    else -> "Plan to Read"
                }

                myLibraryBooks = myLibraryBooks.map {
                    if (it.book.googleBookId == book.googleBookId) {
                        it.copy(
                            currentPage = currentPage,
                            status = newStatus
                        )
                    } else {
                        it
                    }
                }

                kotlinx.coroutines.GlobalScope.launch {
                    val savedBookId = saveBookToBackend(book)

                    if (savedBookId != null) {
                        saveUserBookToBackend(
                            userId = loggedInUserId!!,
                            bookId = savedBookId,
                            currentPage = currentPage,
                            status = newStatus
                        )
                    }
                }
            },
            onLogout = {
                loggedInUserId = null
                loggedInUsername = ""
                loggedInFullName = ""
                showRegisterScreen = false
            }
        )
    } else {
        if (showRegisterScreen) {
            RegisterScreen(onBack = { showRegisterScreen = false })
        } else {
            LoginScreen(
                onLoginSuccess = { userId, username, fullName ->
                    loggedInUserId = userId
                    loggedInUsername = username
                    loggedInFullName = fullName

                    kotlinx.coroutines.GlobalScope.launch {
                        val loadedBooks = loadUserLibrary(userId)
                        myLibraryBooks = loadedBooks
                    }
                },
                onRegisterClick = { showRegisterScreen = true }
            )
        }
    }
}

@Composable
fun LoginScreen(
    onLoginSuccess: (Int, String, String) -> Unit,
    onRegisterClick: () -> Unit
)
{
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var resultMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Mobile Library", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (username.isBlank() || password.isBlank()) {
                    resultMessage = "Please fill all fields"
                } else {
                    scope.launch {
                        val result = loginUser(username, password)
                        resultMessage = result.message

                        if (result.success && result.userId != null) {
                            onLoginSuccess(
                                result.userId,
                                result.username,
                                result.fullName
                            )
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Login")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { onRegisterClick() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Go To Register")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(resultMessage)
    }
}

@Composable
fun RegisterScreen(onBack: () -> Unit) {
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var resultMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Register", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("Full Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirm Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (
                    fullName.isBlank() ||
                    username.isBlank() ||
                    password.isBlank() ||
                    confirmPassword.isBlank()
                ) {
                    resultMessage = "Please fill all fields"
                } else if (password != confirmPassword) {
                    resultMessage = "Passwords do not match"
                } else {
                    scope.launch {
                        val registerResult = registerUser(fullName, username, password)

                        resultMessage = if (registerResult.contains("Register successful")) {
                            "Registration completed successfully. You can now log in."
                        } else {
                            registerResult
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Register")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { onBack() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back To Login")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(resultMessage)
    }
}


@Composable
fun HomeScreen(
    userId: Int,
    username: String,
    fullName: String,
    myLibraryBooks: List<LibraryBook>,
    onAddBook: (GoogleBook) -> Unit,
    onRemoveBook: (GoogleBook) -> Unit,
    onUpdateProgress: (GoogleBook, Int) -> Unit,
    onLogout: () -> Unit
){
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = BottomBarBrown
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Text("🔍") },
                    label = { Text("Explore") }
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Text("📚") },
                    label = { Text("Library") }
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Text("📖") },
                    label = { Text("Journal") }
                )

                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Text("👤") },
                    label = { Text("Profile") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            when (selectedTab) {
                0 -> ExploreScreen(onAddBook = onAddBook)
                1 -> MyLibraryScreen(
                    myLibraryBooks = myLibraryBooks,
                    onRemoveBook = onRemoveBook,
                    onUpdateProgress = onUpdateProgress
                )
                2 -> JournalScreen(
                    userId = userId,
                    myLibraryBooks = myLibraryBooks
                )
                3 -> ProfileScreen(
                    userId = userId,
                    username = username,
                    fullName = fullName,
                    myLibraryBooks = myLibraryBooks,
                    onLogout = onLogout
                )
            }
        }
    }
}

data class GoogleBook(
    val googleBookId: String,
    val title: String,
    val author: String,
    val imageUrl: String,
    val description: String = "No description available.",
    val pageCount: Int = 0
)

data class LibraryBook(
    val book: GoogleBook,
    val status: String = "Plan to Read",
    val currentPage: Int = 0
)
data class JournalEntry(
    val googleBookId: String,
    val entryType: String,
    val text: String,
    val pageNumber: Int
)

@Composable
fun ExploreScreen(onAddBook: (GoogleBook) -> Unit)  {
    var searchText by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Featured") }
    var books by remember { mutableStateOf(listOf<GoogleBook>()) }
    var resultMessage by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()



    val categories = mapOf(

        "Featured" to listOf(
            "The Little Prince",
            "1984",
            "Animal Farm",
            "Dune",
            "The Hobbit",
            "Harry Potter and the Sorcerer's Stone",
            "The Alchemist",
            "To Kill a Mockingbird",
            "Pride and Prejudice",
            "The Great Gatsby",
            "The Catcher in the Rye",
            "The Lord of the Rings",
            "The Martian",
            "Fahrenheit 451",
            "Brave New World",
            "The Count of Monte Cristo",
            "Crime and Punishment",
            "Jane Eyre",
            "Wuthering Heights"
        ),

        "World Classics" to listOf(
            "Crime and Punishment",
            "The Brothers Karamazov",
            "Anna Karenina",
            "War and Peace",
            "Pride and Prejudice",
            "Sense and Sensibility",
            "Emma",
            "Jane Eyre",
            "Wuthering Heights",
            "Les Miserables",
            "The Count of Monte Cristo",
            "Don Quixote",
            "The Picture of Dorian Gray",
            "Dracula",
            "Frankenstein",
            "Moby Dick",
            "Great Expectations",
            "Oliver Twist",
            "Madame Bovary",
            "The Odyssey"

        ),

        "Fantasy" to listOf(
            "Harry Potter and the Sorcerer's Stone",
            "Harry Potter and the Chamber of Secrets",
            "Harry Potter and the Prisoner of Azkaban",
            "The Hobbit",
            "The Fellowship of the Ring",
            "The Two Towers",
            "The Return of the King",
            "The Lion the Witch and the Wardrobe",
            "Prince Caspian",
            "The Voyage of the Dawn Treader",
            "A Game of Thrones",
            "A Clash of Kings",
            "The Wise Man's Fear",
            "Mistborn",
            "The Final Empire",
            "The Well of Ascension",
            "The Eye of the World",
            "The Great Hunt",
            "The Dragon Reborn",
            "Eragon"
        ),

        "Science Fiction" to listOf(
            "Dune",
            "Dune Messiah",
            "Children of Dune",
            "Foundation",
            "Foundation and Empire",
            "Second Foundation",
            "I, Robot",
            "The Caves of Steel",
            "Fahrenheit 451",
            "Brave New World",
            "1984",
            "The Martian",
            "Artemis",
            "Neuromancer",
            "Hyperion",
            "The Left Hand of Darkness",
            "Ender's Game",
            "Do Androids Dream of Electric Sheep",
            "The Hitchhiker's Guide to the Galaxy"
        ),

        "Mystery & Thriller" to listOf(
            "Murder on the Orient Express",
            "And Then There Were None",
            "Death on the Nile",
            "The ABC Murders",
            "The Murder of Roger Ackroyd",
            "Gone Girl",
            "The Girl with the Dragon Tattoo",
            "The Girl Who Played with Fire",
            "The Da Vinci Code",
            "Angels and Demons",
            "Inferno",
            "The Silent Patient",
            "The Woman in the Window",
            "Big Little Lies",
            "Sharp Objects",
            "In the Woods",
            "The Reversal",
            "The Lincoln Lawyer",
            "Shutter Island"
        ),

        "Historical Fiction" to listOf(
            "The Book Thief",
            "All the Light We Cannot See",
            "The Nightingale",
            "Wolf Hall",
            "Bring Up the Bodies",
            "The Pillars of the Earth",
            "World Without End",
            "War and Peace",
            "The Kite Runner",
            "A Thousand Splendid Suns",
            "Memoirs of a Geisha",
            "The Help",
            "The Other Boleyn Girl",
            "The Red Tent",
            "The Alice Network",
            "Code Name Verity",
            "The Paris Library",
            "The Four Winds",
            "Hamnet",
            "The Island of Sea Women"
        ),

        "Romance" to listOf(
            "Pride and Prejudice",
            "Sense and Sensibility",
            "Emma",
            "Persuasion",
            "Jane Eyre",
            "Wuthering Heights",
            "Me Before You",
            "The Notebook",
            "The Fault in Our Stars",
            "Outlander",
            "The Time Traveler's Wife",
            "Eleanor and Park",
            "People We Meet on Vacation",
            "It Ends with Us",
            "It Starts with Us",
            "Ugly Love",
            "November 9",
            "Love and Other Words",
            "Archer's Voice",
            "Twilight"
        ),

        "Self Development" to listOf(
            "Atomic Habits",
            "The 7 Habits of Highly Effective People",
            "Think and Grow Rich",
            "Deep Work",
            "Mindset",
            "Can't Hurt Me",
            "The Power of Habit",
            "Emotional Intelligence",
            "Rich Dad Poor Dad",
            "How to Win Friends and Influence People",
            "The Subtle Art of Not Giving a Fck",
            "The Mountain Is You",
            "Ikigai",
            "Essentialism",
            "Make Your Bed",
            "Start With Why",
            "Leaders Eat Last",
            "The Psychology of Money",
            "Thinking Fast and Slow",
            "The Power of Now"
        ),

        "Children" to listOf(
            "The Little Prince",
            "Alice's Adventures in Wonderland",
            "Charlie and the Chocolate Factory",
            "Matilda",
            "James and the Giant Peach",
            "The BFG",
            "Peter Pan",
            "Heidi",
            "Pinocchio",
            "The Secret Garden",
            "Anne of Green Gables",
            "Charlotte's Web",
            "Winnie the Pooh",
            "The Wind in the Willows",
            "Black Beauty",
            "The Wonderful Wizard of Oz",
            "The Tale of Peter Rabbit",
            "A Little Princess",
            "The Velveteen Rabbit"
        )
    )

    val bookAuthorMap = mapOf(
        "Dune" to "Frank Herbert",
        "1984" to "George Orwell",
        "Animal Farm" to "George Orwell",
        "The Hobbit" to "J.R.R. Tolkien",
        "Harry Potter and the Sorcerer's Stone" to "J.K. Rowling",
        "The Little Prince" to "Antoine de Saint Exupery",
        "The Alchemist" to "Paulo Coelho",
        "To Kill a Mockingbird" to "Harper Lee",
        "Pride and Prejudice" to "Jane Austen",
        "The Great Gatsby" to "F. Scott Fitzgerald",
        "Crime and Punishment" to "Fyodor Dostoevsky",
        "Jane Eyre" to "Charlotte Bronte",
        "Wuthering Heights" to "Emily Bronte",
        "The Martian" to "Andy Weir",
        "Fahrenheit 451" to "Ray Bradbury",
        "Brave New World" to "Aldous Huxley",
        "Foundation" to "Isaac Asimov",
        "I, Robot" to "Isaac Asimov",
        "Murder on the Orient Express" to "Agatha Christie",
        "And Then There Were None" to "Agatha Christie"
    )

    LaunchedEffect(Unit) {
        books = searchCuratedBooks(categories["Featured"] ?: emptyList())
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text("Explore", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = searchText,
            onValueChange = { searchText = it },
            label = { Text("Search books or authors") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                scope.launch {
                    if (searchText.isBlank()) {
                        resultMessage = "Please enter a book title"
                    } else {
                        selectedCategory = "Search Results"
                        resultMessage = "Searching..."
                        books = searchGoogleBooks(searchText)
                        resultMessage = if (books.isEmpty()) "No books found" else ""
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Search")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState())
        ) {
            categories.keys.forEach { category ->
                CategoryChip(category) {
                    scope.launch {
                        selectedCategory = category
                        resultMessage = "Loading..."
                        books = searchCuratedBooks(categories[category] ?: emptyList())
                        resultMessage = ""
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        if (resultMessage.isNotBlank()) {
            Text(resultMessage)
            Spacer(modifier = Modifier.height(10.dp))
        }

        Text(selectedCategory, style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(12.dp))

        GoogleBookGrid(
            books = books,
            onAddBook = onAddBook
        )
    }
}

@Composable
fun CategoryChip(text: String, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(text) },
        modifier = Modifier.padding(end = 8.dp)
    )
}


@Composable
fun GoogleBookGrid(
    books: List<GoogleBook>,
    onAddBook: (GoogleBook) -> Unit
) {
    if (books.isEmpty()) {
        Text("No books available.")
        return
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        items(books) { book ->
            GoogleBookCard(
                book = book,
                onAddBook = onAddBook
            )
        }
    }
}

@Composable
fun GoogleBookCard(
    book: GoogleBook,
    onAddBook: (GoogleBook) -> Unit
) {
    var added by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }

    Card(
        onClick = {
            showDetails = true
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(270.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp)
        ) {
            AsyncImage(
                model = book.imageUrl,
                contentDescription = book.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(book.title, style = MaterialTheme.typography.titleSmall, maxLines = 2)
            Text(book.author, style = MaterialTheme.typography.bodySmall, maxLines = 1)

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    onAddBook(book)
                    added = true
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (added) "✓ Added" else "+")
            }
        }
    }
    if (showDetails) {
        AlertDialog(
            onDismissRequest = {
                showDetails = false
            },

            confirmButton = {
                Button(
                    onClick = {
                        showDetails = false
                    }
                ) {
                    Text("Close")
                }
            },

            title = {
                Text(book.title)
            },

            text = {
                Column(
                    modifier = Modifier
                        .heightIn(max = 500.dp)
                        .verticalScroll(rememberScrollState())
                ) {

                    AsyncImage(
                        model = book.imageUrl,
                        contentDescription = book.title,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp),
                        contentScale = ContentScale.Crop
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        "Author: ${book.author}",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    //          Text(
                    //            book.description,
                    //          style = MaterialTheme.typography.bodySmall
                    //         )
                }
            }
        )
    }}
@Composable
fun LibraryBookCard(
    libraryBook: LibraryBook,
    onRemoveBook: (GoogleBook) -> Unit,
    onUpdateProgress: (GoogleBook, Int) -> Unit
) {
    val book = libraryBook.book
    var showDetails by remember { mutableStateOf(false) }
    var sliderPage by remember { mutableStateOf(libraryBook.currentPage.toFloat()) }

    Card(
        onClick = {
            sliderPage = libraryBook.currentPage.toFloat()
            showDetails = true
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxSize()
        ) {
            AsyncImage(
                model = book.imageUrl,
                contentDescription = book.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(14.dp))
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = book.title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 2
            )

            Text(
                text = book.author,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }

    if (showDetails) {
        Dialog(onDismissRequest = { showDetails = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFCF6)),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = book.title,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            maxLines = 2,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(horizontal = 42.dp)
                        )

                        Text(
                            text = "×",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF333333),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(34.dp)
                                .background(Color(0xFFF1EEE7), CircleShape)
                                .clickable { showDetails = false }
                                .wrapContentSize(Alignment.Center)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    AsyncImage(
                        model = book.imageUrl,
                        contentDescription = book.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .width(150.dp)
                            .height(210.dp)
                            .clip(RoundedCornerShape(18.dp))
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(Color(0xFFEAF0E7), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("👤", fontSize = 18.sp)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text("Author", fontSize = 12.sp, color = Color.Gray)

                            Text(
                                text = book.author,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF222222),
                                maxLines = 2
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(Color(0xFFEAF0E7), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("📖", fontSize = 18.sp)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text("Status", fontSize = 12.sp, color = Color.Gray)

                            Text(
                                text = libraryBook.status,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF4F7D55)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Divider(color = Color(0xFFE6DED2))

                    Spacer(modifier = Modifier.height(14.dp))

                    if (book.pageCount > 0) {
                        val progress = (sliderPage / book.pageCount.toFloat()).coerceIn(0f, 1f)
                        val percent = (progress * 100).toInt()

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFCF6)),
                            border = BorderStroke(1.dp, Color(0xFFE4D8CA))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Reading Progress",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF222222)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${sliderPage.toInt()} / ${book.pageCount}",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF222222)
                                    )

                                    Column(
                                        modifier = Modifier
                                            .background(
                                                Color(0xFFEAF0E7),
                                                RoundedCornerShape(14.dp)
                                            )
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "$percent%",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF4F7D55)
                                        )

                                        Text(
                                            text = "Read",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Slider(
                                    value = sliderPage,
                                    onValueChange = { sliderPage = it },
                                    valueRange = 0f..book.pageCount.toFloat(),
                                    steps = if (book.pageCount > 1) book.pageCount - 1 else 0
                                )

                                Text(
                                    text = "Drag the slider to update your progress",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.align(Alignment.CenterHorizontally)
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Page count information is not available for this book.",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                onRemoveBook(book)
                                showDetails = false
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFD13A2F)
                            ),
                            border = BorderStroke(1.dp, Color(0xFFD13A2F))
                        ) {
                            Text("Remove", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                onUpdateProgress(book, sliderPage.toInt())
                                showDetails = false
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF4F7D55)
                            )
                        ) {
                            Text("Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun MyLibraryScreen(
    myLibraryBooks: List<LibraryBook>,
    onRemoveBook: (GoogleBook) -> Unit,
    onUpdateProgress: (GoogleBook, Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 8.dp, end = 16.dp, top = 20.dp, bottom = 60.dp)
    ) {
        Text(
            text = "My Library",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(28.dp))

        if (myLibraryBooks.isEmpty()) {
            Text(
                text = "You haven't added any books to your library yet.",
                style = MaterialTheme.typography.bodyLarge
            )
        } else {
            LibrarySection(
                title = "Plan to Read",
                books = myLibraryBooks.filter { it.status == "Plan to Read" },
                onRemoveBook = onRemoveBook,
                onUpdateProgress = onUpdateProgress
            )

            Spacer(modifier = Modifier.height(28.dp))

            LibrarySection(
                title = "Reading",
                books = myLibraryBooks.filter { it.status == "Reading" },
                onRemoveBook = onRemoveBook,
                onUpdateProgress = onUpdateProgress
            )

            Spacer(modifier = Modifier.height(28.dp))

            LibrarySection(
                title = "Completed",
                books = myLibraryBooks.filter { it.status == "Completed" },
                onRemoveBook = onRemoveBook,
                onUpdateProgress = onUpdateProgress
            )
        }
    }
}

@Composable
fun LibrarySection(
    title: String,
    books: List<LibraryBook>,
    onRemoveBook: (GoogleBook) -> Unit,
    onUpdateProgress: (GoogleBook, Int) -> Unit
) {
    Text(
        text = title,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Medium,
        fontSize = 20.sp,
        color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(10.dp))

    if (books.isEmpty()) {
        Text("No books in this section.")
    } else {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(end = 16.dp)
        ) {
            items(books) { libraryBook ->
                Box(
                    modifier = Modifier.width(145.dp)
                ) {
                    LibraryBookCard(
                        libraryBook = libraryBook,
                        onRemoveBook = onRemoveBook,
                        onUpdateProgress = onUpdateProgress
                    )
                }
            }
        }
    }
}

@Composable
fun JournalScreen(
    userId: Int,
    myLibraryBooks: List<LibraryBook>
) {
    var openBookJournal by remember { mutableStateOf(false) }
    var selectedBookName by remember { mutableStateOf("") }
    var selectedBookId by remember { mutableStateOf("") }

    var showAddExpectation by remember { mutableStateOf(false) }
    var expectationText by remember { mutableStateOf("") }
    var expectations by remember { mutableStateOf(mapOf<String, String>()) }

    var showAddReadingNote by remember { mutableStateOf(false) }
    var readingNotePage by remember { mutableStateOf("") }
    var readingNoteText by remember { mutableStateOf("") }
    var readingNotes by remember {
        mutableStateOf(mapOf<String, List<Pair<Int, String>>>())
    }
    var showAddQuote by remember { mutableStateOf(false) }
    var quotePage by remember { mutableStateOf("") }
    var quoteText by remember { mutableStateOf("") }
    var quotes by remember {
        mutableStateOf(mapOf<String, List<Pair<Int, String>>>())
    }
    var showAddFinalThought by remember { mutableStateOf(false) }
    var finalThoughtText by remember { mutableStateOf("") }
    var finalThoughts by remember {
        mutableStateOf(mapOf<String, String>())
    }

    var noteToDelete by remember {
        mutableStateOf<Pair<Int, String>?>(null)
    }

    var showDeleteNoteDialog by remember {
        mutableStateOf(false)
    }

    var quoteToDelete by remember {
        mutableStateOf<Pair<Int, String>?>(null)
    }

    var showDeleteQuoteDialog by remember {
        mutableStateOf(false)
    }

    LaunchedEffect(userId) {

        val entries = loadJournalEntries(userId)

        val loadedExpectations = mutableMapOf<String, String>()
        val loadedReadingNotes = mutableMapOf<String, MutableList<Pair<Int, String>>>()
        val loadedQuotes = mutableMapOf<String, MutableList<Pair<Int, String>>>()
        val loadedFinalThoughts = mutableMapOf<String, String>()

        entries.forEach { entry ->

            when (entry.entryType) {

                "expectation" -> {
                    loadedExpectations[entry.googleBookId] = entry.text
                }

                "note" -> {
                    loadedReadingNotes
                        .getOrPut(entry.googleBookId) { mutableListOf() }
                        .add(Pair(entry.pageNumber, entry.text))
                }

                "quote" -> {
                    loadedQuotes
                        .getOrPut(entry.googleBookId) { mutableListOf() }
                        .add(Pair(entry.pageNumber, entry.text))
                }

                "final_thought" -> {
                    loadedFinalThoughts[entry.googleBookId] = entry.text
                }
            }
        }

        expectations = loadedExpectations

        readingNotes =
            loadedReadingNotes.mapValues { it.value.toList() }

        quotes =
            loadedQuotes.mapValues { it.value.toList() }

        finalThoughts = loadedFinalThoughts
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text("Reading Journal", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        if (!openBookJournal) {
            Text("Select Book", style = MaterialTheme.typography.titleMedium)

            Spacer(modifier = Modifier.height(10.dp))

            if (myLibraryBooks.isEmpty()) {
                Text("Add books to your library before using the journal.")
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(myLibraryBooks) { libraryBook ->
                        val book = libraryBook.book

                        Card(
                            onClick = {
                                selectedBookName = book.title
                                selectedBookId = book.googleBookId
                                expectationText = expectations[book.googleBookId] ?: ""
                                openBookJournal = true
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp),
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxSize()
                            ) {
                                AsyncImage(
                                    model = book.imageUrl,
                                    contentDescription = book.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(120.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = book.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 2
                                )

                                Text(
                                    text = book.author,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 2,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            }
        } else {
            val selectedLibraryBook = myLibraryBooks.firstOrNull {
                it.book.googleBookId == selectedBookId
            }

            val isCompleted = selectedLibraryBook?.status == "Completed"

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                Button(
                    onClick = {
                        openBookJournal = false
                        selectedBookName = ""
                        selectedBookId = ""
                        showAddExpectation = false
                        showAddReadingNote = false
                    }
                ) {
                    Text("← Back")
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "$selectedBookName Journal",
                    style = MaterialTheme.typography.headlineSmall
                )

                Spacer(modifier = Modifier.height(20.dp))

                Text("Expectation", style = MaterialTheme.typography.titleMedium)

                Spacer(modifier = Modifier.height(8.dp))

                val currentExpectation = expectations[selectedBookId]

                JournalTextCard(
                    text = currentExpectation ?: "What do you expect from this book?"
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (!showAddExpectation) {
                    Button(
                        onClick = {
                            expectationText = currentExpectation ?: ""
                            showAddExpectation = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (currentExpectation.isNullOrBlank())
                                "Add Expectation"
                            else
                                "Edit Expectation"
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = expectationText,
                        onValueChange = { expectationText = it },
                        label = { Text("Write your expectation before reading") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (expectationText.isNotBlank()) {
                                expectations = expectations + (selectedBookId to expectationText)
                                showAddExpectation = false

                                kotlinx.coroutines.GlobalScope.launch {
                                    saveJournalEntryToBackend(
                                        userId = userId,
                                        googleBookId = selectedBookId,
                                        entryType = "expectation",
                                        text = expectationText,
                                        pageNumber = 0
                                    )
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Expectation")
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { showAddExpectation = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cancel")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Notes", style = MaterialTheme.typography.titleMedium)

                Spacer(modifier = Modifier.height(8.dp))

                val currentNotes = readingNotes[selectedBookId] ?: emptyList()

                if (currentNotes.isEmpty()) {
                    Text("Start capturing your thoughts while reading.")
                } else {
                    currentNotes.forEach { note ->
                        JournalNoteCard(
                            page = note.first,
                            text = note.second,
                            isQuote = false,
                            onDelete = {
                                noteToDelete = note
                                showDeleteNoteDialog = true
                            }
                        )
                    }


                }

                Spacer(modifier = Modifier.height(10.dp))

                if (!showAddReadingNote) {
                    Button(
                        onClick = { showAddReadingNote = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add Note")
                    }
                } else {
                    OutlinedTextField(
                        value = readingNotePage,
                        onValueChange = { readingNotePage = it },
                        label = { Text("Page Number") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = readingNoteText,
                        onValueChange = { readingNoteText = it },
                        label = { Text("Reading Note") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val page = readingNotePage.toIntOrNull()

                            if (page != null && readingNoteText.isNotBlank()) {
                                val noteTextToSave = readingNoteText
                                val oldNotes = readingNotes[selectedBookId] ?: emptyList()

                                readingNotes = readingNotes + (
                                        selectedBookId to (oldNotes + Pair(page, readingNoteText))
                                        )

                                kotlinx.coroutines.GlobalScope.launch {
                                    saveJournalEntryToBackend(
                                        userId = userId,
                                        googleBookId = selectedBookId,
                                        entryType = "note",
                                        text = noteTextToSave,
                                        pageNumber = page
                                    )
                                }

                                readingNotePage = ""
                                readingNoteText = ""
                                showAddReadingNote = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Note")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            readingNotePage = ""
                            readingNoteText = ""
                            showAddReadingNote = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cancel")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Quotes", style = MaterialTheme.typography.titleMedium)

                Spacer(modifier = Modifier.height(8.dp))

                val currentQuotes = quotes[selectedBookId] ?: emptyList()

                if (currentQuotes.isEmpty()) {
                    Text("Save your favorite quotes from this book.")
                } else {
                    currentQuotes.forEach { quote ->
                        JournalNoteCard(
                            page = quote.first,
                            text = quote.second,
                            isQuote = true,
                            onDelete = {
                                quoteToDelete = quote
                                showDeleteQuoteDialog = true
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (!showAddQuote) {
                    Button(
                        onClick = { showAddQuote = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add Quote")
                    }
                } else {
                    OutlinedTextField(
                        value = quotePage,
                        onValueChange = { quotePage = it },
                        label = { Text("Page Number") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = quoteText,
                        onValueChange = { quoteText = it },
                        label = { Text("Quote") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val page = quotePage.toIntOrNull()

                            if (page != null && quoteText.isNotBlank()) {
                                val quoteTextToSave = quoteText
                                val oldQuotes = quotes[selectedBookId] ?: emptyList()

                                quotes = quotes + (
                                        selectedBookId to (oldQuotes + Pair(page, quoteText))
                                        )
                                kotlinx.coroutines.GlobalScope.launch {
                                    saveJournalEntryToBackend(
                                        userId = userId,
                                        googleBookId = selectedBookId,
                                        entryType = "quote",
                                        text = quoteTextToSave,
                                        pageNumber = page
                                    )
                                }

                                quotePage = ""
                                quoteText = ""
                                showAddQuote = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Quote")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            quotePage = ""
                            quoteText = ""
                            showAddQuote = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cancel")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Final Thoughts", style = MaterialTheme.typography.titleMedium)

                Spacer(modifier = Modifier.height(8.dp))

                val currentFinalThought = finalThoughts[selectedBookId]

                if (!isCompleted) {
                    Text("You can write your final review after finishing the book.")
                } else {
                    JournalTextCard(
                        text = currentFinalThought ?: "Share your final thoughts about this book."
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (!showAddFinalThought) {
                        Button(
                            onClick = {
                                finalThoughtText = currentFinalThought ?: ""
                                showAddFinalThought = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (currentFinalThought.isNullOrBlank())
                                    "Add Final Thought"
                                else
                                    "Edit Final Thought"
                            )
                        }
                    } else {
                        OutlinedTextField(
                            value = finalThoughtText,
                            onValueChange = { finalThoughtText = it },
                            label = { Text("Final Thoughts") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                if (finalThoughtText.isNotBlank()) {

                                    val finalThoughtToSave = finalThoughtText

                                    finalThoughts = finalThoughts + (
                                            selectedBookId to finalThoughtToSave
                                            )

                                    kotlinx.coroutines.GlobalScope.launch {
                                        saveJournalEntryToBackend(
                                            userId = userId,
                                            googleBookId = selectedBookId,
                                            entryType = "final_thought",
                                            text = finalThoughtToSave,
                                            pageNumber = 0
                                        )
                                    }

                                    finalThoughtText = ""
                                    showAddFinalThought = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Final Thought")
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                showAddFinalThought = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }
    }

    if (showDeleteNoteDialog && noteToDelete != null) {

        AlertDialog(
            onDismissRequest = {
                showDeleteNoteDialog = false
            },

            title = {
                Text("Delete Note")
            },

            text = {
                Text("Are you sure you want to delete this note?")
            },

            confirmButton = {
                Button(
                    onClick = {

                        val note = noteToDelete

                        if (note != null) {

                            val oldNotes =
                                readingNotes[selectedBookId] ?: emptyList()

                            readingNotes = readingNotes + (
                                    selectedBookId to oldNotes.filter {
                                        it != note
                                    }
                                    )

                            kotlinx.coroutines.GlobalScope.launch {
                                deleteJournalEntry(
                                    userId = userId,
                                    googleBookId = selectedBookId,
                                    entryType = "note",
                                    pageNumber = note.first,
                                    text = note.second
                                )
                            }
                        }

                        showDeleteNoteDialog = false
                        noteToDelete = null
                    }
                ) {
                    Text("Delete")
                }
            },

            dismissButton = {
                Button(
                    onClick = {
                        showDeleteNoteDialog = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
    if (showDeleteQuoteDialog && quoteToDelete != null) {

        AlertDialog(
            onDismissRequest = {
                showDeleteQuoteDialog = false
            },

            title = {
                Text("Delete Quote")
            },

            text = {
                Text("Are you sure you want to delete this quote?")
            },

            confirmButton = {
                Button(
                    onClick = {

                        val quote = quoteToDelete

                        if (quote != null) {

                            val oldQuotes =
                                quotes[selectedBookId] ?: emptyList()

                            quotes = quotes + (
                                    selectedBookId to oldQuotes.filter {
                                        it != quote
                                    }
                                    )

                            kotlinx.coroutines.GlobalScope.launch {
                                deleteJournalEntry(
                                    userId = userId,
                                    googleBookId = selectedBookId,
                                    entryType = "quote",
                                    pageNumber = quote.first,
                                    text = quote.second
                                )
                            }
                        }

                        showDeleteQuoteDialog = false
                        quoteToDelete = null
                    }
                ) {
                    Text("Delete")
                }
            },

            dismissButton = {
                Button(
                    onClick = {
                        showDeleteQuoteDialog = false
                        quoteToDelete = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

}

@Composable
fun JournalNoteCard(
    page: Int,
    text: String,
    isQuote: Boolean,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF4EEE5)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Box(
                    modifier = Modifier
                        .background(
                            Color(0xFFEAF0E7),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(
                            horizontal = 10.dp,
                            vertical = 4.dp
                        )
                ) {
                    Text(
                        text = "📄 Page $page",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                IconButton(
                    onClick = onDelete
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete"
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isQuote) {

                Text(
                    text = "❝",
                    fontSize = 28.sp,
                    color = Color(0xFF6B8E6E)
                )

                Text(
                    text = text,
                    fontSize = 17.sp,
                    fontStyle = FontStyle.Italic
                )

                Text(
                    text = "❞",
                    fontSize = 28.sp,
                    color = Color(0xFF6B8E6E),
                    modifier = Modifier.align(Alignment.End)
                )

            } else {

                Text(
                    text = text,
                    fontSize = 16.sp,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
fun JournalTextCard(
    text: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF7F2EA)
        )
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            lineHeight = 24.sp,
            color = Color(0xFF2F2B26),
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Composable
fun ProfileScreen(
    userId: Int,
    username: String,
    fullName: String,
    myLibraryBooks: List<LibraryBook>,
    onLogout: () -> Unit
) {
    val totalBooks = myLibraryBooks.size
    val completedBooks = myLibraryBooks.count { it.status == "Completed" }
    val readingBooks = myLibraryBooks.count { it.status == "Reading" }
    val planToReadBooks = myLibraryBooks.count { it.status == "Plan to Read" }
    val totalPagesLogged = myLibraryBooks.sumOf { it.currentPage }

    var selectedColor by remember { mutableStateOf(Color(0xFF6B8E6E)) }
    var avatarTextColor by remember { mutableStateOf(Color(0xFF2F2B26)) }
    var favoriteGenre by remember { mutableStateOf("Fantasy") }
    var showGenreDialog by remember { mutableStateOf(false) }

    var dailyGoal by remember { mutableStateOf(20) }
    var showGoalDialog by remember { mutableStateOf(false) }
    var goalInput by remember { mutableStateOf(dailyGoal.toString()) }

    val genres = listOf(
        "Fantasy",
        "Science Fiction",
        "Mystery",
        "Romance",
        "Classics",
        "Historical Fiction",
        "Self Development"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Profile",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 30.sp,
            color = Color(0xFF2F2B26)
        )

        Spacer(modifier = Modifier.height(10.dp))

        val initial = if (fullName.isNotBlank()) fullName.first().uppercase() else "U"

        Card(
            modifier = Modifier.size(88.dp),
            shape = CircleShape,
            colors = CardDefaults.cardColors(
                containerColor = selectedColor.copy(alpha = 0.18f)
            )
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initial,
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Bold,
                    color = avatarTextColor,
                    modifier = Modifier.clickable {
                        avatarTextColor = when (avatarTextColor) {
                            Color(0xFF2F2B26) -> Color(0xFF6B8E6E)
                            Color(0xFF6B8E6E) -> Color(0xFF8B6F47)
                            Color(0xFF8B6F47) -> Color(0xFF6D7893)
                            else -> Color(0xFF2F2B26)
                        }
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = fullName,
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF2F2B26)
        )

        Text(
            text = "@$username",
            fontSize = 15.sp,
            color = Color(0xFF5F5A52)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ColorCircle(Color(0xFF6B8E6E), selectedColor) {
                selectedColor = Color(0xFF6B8E6E)
            }
            ColorCircle(Color(0xFF8B6F47), selectedColor) {
                selectedColor = Color(0xFF8B6F47)
            }
            ColorCircle(Color(0xFF9B6B6B), selectedColor) {
                selectedColor = Color(0xFF9B6B6B)
            }
            ColorCircle(Color(0xFF6D7893), selectedColor) {
                selectedColor = Color(0xFF6D7893)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        ProfileSectionTitle("Reading Statistics")

        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard(totalBooks.toString(), "Books", selectedColor, Modifier.weight(1f))
                StatCard(completedBooks.toString(), "Completed", selectedColor, Modifier.weight(1f))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard(readingBooks.toString(), "Reading", selectedColor, Modifier.weight(1f))
                StatCard(planToReadBooks.toString(), "Planned", selectedColor, Modifier.weight(1f))
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        ProfileSectionTitle("Favorite Genre")

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(82.dp)
                .clickable { showGenreDialog = true },
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = selectedColor.copy(alpha = 0.16f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("✨", fontSize = 24.sp)

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = favoriteGenre,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2F2B26)
                    )

                    Text(
                        text = "Tap to change",
                        fontSize = 12.sp,
                        color = Color(0xFF5F5A52)
                    )
                }

                Text(
                    text = "Change",
                    color = selectedColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        ProfileSectionTitle("Reading Goals")

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFCF6)),
            border = BorderStroke(1.dp, Color(0xFFE4D8CA))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            goalInput = dailyGoal.toString()
                            showGoalDialog = true
                        },
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Daily Goal", fontSize = 14.sp)
                    Text("$dailyGoal pages", fontSize = 14.sp, color = selectedColor)
                }
                Text("Total Pages Logged: $totalPagesLogged pages", fontSize = 14.sp)
                Text("Active Reading Books: $readingBooks", fontSize = 14.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { onLogout() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = selectedColor)
        ) {
            Text("Logout", fontWeight = FontWeight.Bold)
        }
    }

    if (showGenreDialog) {
        AlertDialog(
            onDismissRequest = { showGenreDialog = false },
            title = { Text("Select Favorite Genre") },
            text = {
                Column {
                    genres.forEach { genre ->
                        Text(
                            text = genre,
                            fontSize = 17.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    favoriteGenre = genre
                                    showGenreDialog = false
                                }
                                .padding(vertical = 9.dp)
                        )
                    }
                }
            },
            confirmButton = {}
        )
    }
    if (showGoalDialog) {
        AlertDialog(
            onDismissRequest = { showGoalDialog = false },
            title = { Text("Set Daily Goal") },
            text = {
                OutlinedTextField(
                    value = goalInput,
                    onValueChange = { goalInput = it },
                    label = { Text("Pages per day") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newGoal = goalInput.toIntOrNull()

                        if (newGoal != null && newGoal > 0) {
                            dailyGoal = newGoal
                            showGoalDialog = false
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showGoalDialog = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ProfileSectionTitle(text: String) {
    Text(
        text = text,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        color = Color(0xFF2F2B26),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun StatCard(
    number: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(78.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFCF6)),
        border = BorderStroke(1.dp, Color(0xFFE4D8CA)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = number,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )

            Text(
                text = label,
                fontSize = 12.sp,
                color = Color(0xFF5F5A52),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ColorCircle(
    color: Color,
    selectedColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(if (color == selectedColor) 30.dp else 24.dp)
            .clip(CircleShape)
            .background(color)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (color == selectedColor) {
            Text("✓", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}
data class LoginResult(
    val success: Boolean,
    val message: String,
    val userId: Int? = null,
    val username: String = "",
    val fullName: String = ""
)

suspend fun loginUser(
    username: String,
    password: String
): LoginResult {
    return withContext(Dispatchers.IO) {
        try {
            val encodedUsername = URLEncoder.encode(username, "UTF-8")
            val encodedPassword = URLEncoder.encode(password, "UTF-8")

            val url = URL(
                "$BASE_URL/login?username=$encodedUsername&password=$encodedPassword"
            )

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseText =
                connection.inputStream.bufferedReader().use { it.readText() }

            connection.disconnect()

            if (responseText.contains("Login successful")) {
                val userId =
                    Regex("\"user_id\":\\s*(\\d+)")
                        .find(responseText)
                        ?.groupValues
                        ?.get(1)
                        ?.toInt()

                val usernameValue =
                    Regex("\"username\":\\s*\"([^\"]+)\"")
                        .find(responseText)
                        ?.groupValues
                        ?.get(1) ?: ""

                val fullNameValue =
                    Regex("\"full_name\":\\s*\"([^\"]+)\"")
                        .find(responseText)
                        ?.groupValues
                        ?.get(1) ?: ""

                LoginResult(
                    success = true,
                    message = "Login successful",
                    userId = userId,
                    username = usernameValue,
                    fullName = fullNameValue
                )
            } else {
                LoginResult(false, responseText)
            }

        } catch (e: Exception) {
            Log.e("LOGIN_ERROR", e.toString())
            LoginResult(false, "Error: ${e.message}")
        }
    }
}

suspend fun registerUser(
    fullName: String,
    username: String,
    password: String
): String {
    return withContext(Dispatchers.IO) {
        try {
            val encodedFullName = URLEncoder.encode(fullName, "UTF-8")
            val encodedUsername = URLEncoder.encode(username, "UTF-8")
            val encodedPassword = URLEncoder.encode(password, "UTF-8")

            val url = URL(
                "$BASE_URL/users?full_name=$encodedFullName&username=$encodedUsername&password=$encodedPassword"
            )

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseText =
                connection.inputStream.bufferedReader().use { it.readText() }

            connection.disconnect()

            responseText

        } catch (e: Exception) {
            Log.e("REGISTER_ERROR", e.toString())
            "Error: ${e.message}"
        }
    }
}
suspend fun saveBookToBackend(book: GoogleBook): Int? {
    return withContext(Dispatchers.IO) {
        try {
            val encodedGoogleBookId = URLEncoder.encode(book.googleBookId, "UTF-8")
            val encodedTitle = URLEncoder.encode(book.title, "UTF-8")
            val encodedAuthor = URLEncoder.encode(book.author, "UTF-8")
            val encodedImageUrl = URLEncoder.encode(book.imageUrl, "UTF-8")
            val encodedDescription = URLEncoder.encode(book.description, "UTF-8")

            val url = URL(
                "$BASE_URL/books" +
                        "?google_book_id=$encodedGoogleBookId" +
                        "&title=$encodedTitle" +
                        "&author=$encodedAuthor" +
                        "&image_url=$encodedImageUrl" +
                        "&description=$encodedDescription" +
                        "&page_count=${book.pageCount}"
            )

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseText =
                connection.inputStream.bufferedReader().use { it.readText() }

            connection.disconnect()

            Regex("\"id\":\\s*(\\d+)")
                .find(responseText)
                ?.groupValues
                ?.get(1)
                ?.toInt()

        } catch (e: Exception) {
            Log.e("SAVE_BOOK_ERROR", e.toString())
            null
        }
    }
}

suspend fun saveUserBookToBackend(
    userId: Int,
    bookId: Int,
    currentPage: Int,
    status: String
): Boolean {
    return withContext(Dispatchers.IO) {
        try {
            val encodedStatus = URLEncoder.encode(status, "UTF-8")

            val url = URL(
                "$BASE_URL/userbooks" +
                        "?user_id=$userId" +
                        "&book_id=$bookId" +
                        "&current_page=$currentPage" +
                        "&status=$encodedStatus"
            )

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            true
        } catch (e: Exception) {
            Log.e("SAVE_USER_BOOK_ERROR", e.toString())
            false
        }
    }
}

suspend fun loadUserLibrary(userId: Int): List<LibraryBook> {
    return withContext(Dispatchers.IO) {
        try {
            val url = URL("$BASE_URL/userbooks/$userId")

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseText =
                connection.inputStream.bufferedReader().use { it.readText() }

            connection.disconnect()

            val jsonArray = org.json.JSONArray(responseText)
            val loadedBooks = mutableListOf<LibraryBook>()

            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)

                val book = GoogleBook(
                    googleBookId = item.optString("google_book_id", ""),
                    title = item.optString("title", ""),
                    author = item.optString("author", ""),
                    imageUrl = item.optString("image_url", ""),
                    description = item.optString("description", ""),
                    pageCount = item.optInt("page_count", 0)
                )

                val libraryBook = LibraryBook(
                    book = book,
                    status = item.optString("status", "Plan to Read"),
                    currentPage = item.optInt("current_page", 0)
                )

                loadedBooks.add(libraryBook)
            }

            loadedBooks

        } catch (e: Exception) {
            Log.e("LOAD_LIBRARY_ERROR", e.toString())
            emptyList()
        }
    }
}

suspend fun removeBookFromBackend(
    userId: Int,
    googleBookId: String
): Boolean {
    return withContext(Dispatchers.IO) {
        try {
            val encodedBookId =
                URLEncoder.encode(googleBookId, "UTF-8")

            val url = URL(
                "$BASE_URL/userbooks" +
                        "?user_id=$userId" +
                        "&google_book_id=$encodedBookId"
            )

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "DELETE"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            connection.inputStream.bufferedReader().use {
                it.readText()
            }

            connection.disconnect()

            true

        } catch (e: Exception) {
            Log.e("REMOVE_BOOK_ERROR", e.toString())
            false
        }
    }
}

suspend fun saveJournalEntryToBackend(
    userId: Int,
    googleBookId: String,
    entryType: String,
    text: String,
    pageNumber: Int = 0
): Boolean {
    return withContext(Dispatchers.IO) {
        try {

            Log.d(
                "JOURNAL_TEST",
                "$entryType | $text | $pageNumber"
            )
            val encodedBookId = URLEncoder.encode(googleBookId, "UTF-8")
            val encodedType = URLEncoder.encode(entryType, "UTF-8")
            val encodedText = URLEncoder.encode(text, "UTF-8")

            val url = URL(
                "$BASE_URL/journal_entries" +
                        "?user_id=$userId" +
                        "&google_book_id=$encodedBookId" +
                        "&entry_type=$encodedType" +
                        "&text=$encodedText" +
                        "&page_number=$pageNumber"
            )

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            true
        } catch (e: Exception) {
            Log.e("SAVE_JOURNAL_ENTRY_ERROR", e.toString())
            false
        }
    }
}

suspend fun loadJournalEntries(
    userId: Int
): List<JournalEntry> {
    return withContext(Dispatchers.IO) {
        try {
            val url = URL("$BASE_URL/journal_entries/$userId")

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseText =
                connection.inputStream.bufferedReader().use { it.readText() }

            connection.disconnect()

            val jsonArray = org.json.JSONArray(responseText)

            val entries = mutableListOf<JournalEntry>()

            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)

                entries.add(
                    JournalEntry(
                        googleBookId = item.getString("google_book_id"),
                        entryType = item.getString("entry_type"),
                        text = item.getString("text"),
                        pageNumber = item.getInt("page_number")
                    )
                )
            }

            entries

        } catch (e: Exception) {
            Log.e("LOAD_JOURNAL_ERROR", e.toString())
            emptyList()
        }
    }
}

suspend fun deleteJournalEntry(
    userId: Int,
    googleBookId: String,
    entryType: String,
    pageNumber: Int,
    text: String
): Boolean {
    return withContext(Dispatchers.IO) {
        try {

            val encodedBookId =
                URLEncoder.encode(googleBookId, "UTF-8")

            val encodedText =
                URLEncoder.encode(text, "UTF-8")

            val url = URL(
                "$BASE_URL/journal_entries" +
                        "?user_id=$userId" +
                        "&google_book_id=$encodedBookId" +
                        "&entry_type=$entryType" +
                        "&page_number=$pageNumber" +
                        "&text=$encodedText"
            )

            val connection =
                url.openConnection() as HttpURLConnection

            connection.requestMethod = "DELETE"

            connection.inputStream.bufferedReader().use {
                it.readText()
            }

            connection.disconnect()

            true

        } catch (e: Exception) {
            Log.e("DELETE_JOURNAL_ERROR", e.toString())
            false
        }
    }
}

suspend fun addJournalNote(
    userId: Int,
    bookId: Int,
    noteText: String
): String {
    return withContext(Dispatchers.IO) {
        try {
            val encodedNote = URLEncoder.encode(noteText, "UTF-8")

            val url = URL(
                "$BASE_URL/journal?user_id=$userId&book_id=$bookId&note_text=$encodedNote"
            )

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseText =
                connection.inputStream.bufferedReader().use { it.readText() }

            connection.disconnect()

            responseText

        } catch (e: Exception) {
            Log.e("JOURNAL_ERROR", e.toString())
            "Error: ${e.message}"
        }
    }
}

suspend fun searchCuratedBooks(bookNames: List<String>): List<GoogleBook> {
    val result = mutableListOf<GoogleBook>()

    for (bookName in bookNames) {
        val foundBooks = searchGoogleBooks(bookName)

        val bestBook = foundBooks.maxByOrNull {
            scoreBook(it, bookName)
        }

        if (bestBook != null) {
            result.add(bestBook)
        }
    }

    return result.distinctBy {
        it.title.lowercase().trim() + it.author.lowercase().trim()
    }
}

suspend fun searchGoogleBooks(
    query: String,
    scoreQuery: String = query,
    alreadyFormatted: Boolean = false
): List<GoogleBook> {
    return withContext(Dispatchers.IO) {
        try {
            val cleanQuery = query.trim()

            val searchQuery = if (alreadyFormatted) {
                cleanQuery
            } else {
                "intitle:$cleanQuery"
            }

            val encodedQuery = URLEncoder.encode(searchQuery, "UTF-8")

            val url = URL(
                "https://www.googleapis.com/books/v1/volumes?q=$encodedQuery&maxResults=40&printType=books&langRestrict=en&key="
            )

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 7000
            connection.readTimeout = 7000

            val responseCode = connection.responseCode

            val responseText = if (responseCode in 200..299) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                val errorText = connection.errorStream?.bufferedReader()?.use { it.readText() }
                Log.e("GOOGLE_BOOKS_HTTP", "Code: $responseCode Error: $errorText")
                return@withContext emptyList()
            }

            connection.disconnect()

            val jsonObject = JSONObject(responseText)
            val items = jsonObject.optJSONArray("items") ?: return@withContext emptyList()

            val bookList = mutableListOf<GoogleBook>()

            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val id = item.optString("id", "")
                val volumeInfo = item.optJSONObject("volumeInfo") ?: continue

                val title = volumeInfo.optString("title", "").trim()
                if (title.isBlank()) continue

                val authorsArray = volumeInfo.optJSONArray("authors")
                val author = if (authorsArray != null && authorsArray.length() > 0) {
                    authorsArray.getString(0)
                } else {
                    ""
                }

                if (author.isBlank()) continue

                val imageLinks = volumeInfo.optJSONObject("imageLinks")
                var imageUrl = imageLinks?.optString("thumbnail", "") ?: ""

                if (imageUrl.isBlank()) continue

                if (imageUrl.startsWith("http://")) {
                    imageUrl = imageUrl.replace("http://", "https://")
                }

                val rawDescription = volumeInfo.optString("description", "").trim()

                val description = if (rawDescription.isBlank()) {
                    "No short description is available for this book."
                } else {
                    rawDescription
                }

                val pageCount = volumeInfo.optInt("pageCount", 0)

                bookList.add(
                    GoogleBook(
                        googleBookId = id,
                        title = title,
                        author = author,
                        imageUrl = imageUrl,
                        description = description,
                        pageCount = pageCount
                    )
                )
            }

            bookList
                .distinctBy { it.googleBookId }
                .sortedByDescending { scoreBook(it, scoreQuery) }

        } catch (e: Exception) {
            Log.e("GOOGLE_BOOKS_ERROR", e.toString())
            emptyList()
        }
    }
}
fun scoreBook(book: GoogleBook, query: String): Int {
    val title = book.title.lowercase().trim()
    val author = book.author.lowercase().trim()
    val q = query.lowercase().trim()

    var score = 0

    val queryWords = q.split(" ").filter { it.length > 2 }
    val titleWords = title.split(" ")

    if (title == q) score += 500
    if (title.startsWith(q)) score += 250
    if (title.contains(q)) score += 180

    if (queryWords.isNotEmpty() && queryWords.all { title.contains(it) }) {
        score += 120
    }

    val extraTitleWords = titleWords.size - queryWords.size
    if (extraTitleWords > 3) {
        score -= extraTitleWords * 20
    }

    if (book.imageUrl.isNotBlank()) score += 50
    if (book.description.isNotBlank()) score += 25
    if (book.pageCount >= 100) score += 30
    if (book.pageCount in 1..80) score -= 80
    if (author.isNotBlank()) score += 25

    val badWords = listOf(
        "summary", "study guide", "analysis", "workbook",
        "notes", "companion", "guide", "unauthorized",
        "notebook", "journal", "calendar", "agenda",
        "magazine", "catalog", "book notes", "sparknotes",
        "lesson plans", "teacher guide", "quiz", "test prep"
    )

    if (badWords.any { title.contains(it) }) {
        score -= 500
    }

    val nonEnglishSignals = listOf(
        "felsefe taşı", "ölüm yadigarları", "sırlar odası",
        "ateş kadehi", "azkaban tutsağı", "melez prens",
        "zümrüdüanka", "ve felsefe", "ve ölüm"
    )

    if (nonEnglishSignals.any { title.contains(it) }) {
        score -= 600
    }

    if (
        q.contains("harry potter") &&
        author.contains("rowling") &&
        !nonEnglishSignals.any { title.contains(it) }
    ) {
        score += 250
    }

    if (
        q.contains("dune") &&
        author.contains("frank herbert") &&
        title == "dune"
    ) {
        score += 300
    }

    return score
}